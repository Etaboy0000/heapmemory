#ifndef HM_H_INCLUDED
#define HM_H_INCLUDED

void* mon_malloc(int size);

void mon_free(void*pointer);
#endif // HM_H_INCLUDED

//sbrk adr de debut, brk deplacer
//code capable de creer une liste chainee
//champs taille du neoud
//app qui permet de cree ou supprime un element dans une liste chainee
